(function(window){
/*
 * 立即投注，通知客户端
 */
var betNow = function( redArr, blue ){
	window.location.href = "caipiao://openssq//"+redArr.join(" ")+":"+ blue;
}
//获取dom节点
wrap = document.getElementById("ssq_wrap");
/*
 <div><span class="redball" id="first"><input name="ssq_r" readonly/></span><span class="redball"><input name="ssq_r" readonly/></span><span class="redball"><input name="ssq_r" readonly/></span><span class="redball"><input name="ssq_r" readonly/></span><span class="redball"><input name="ssq_r" readonly/></span><span class="redball"><input name="ssq_r" readonly/></span><span class="blueball"><input name="ssq_b" readonly/></span></div>
 <div class="ssq_bb"><a id="ssq_br" class="ssqgrayBtn">换一注</a><a class="ssqredBtn" id="ssq_bn">立即投注</a></div>
 */
//插入dom,这里偷懒了，因为不太常用
wrap.innerHTML = "<div><span class='redball' id='first'><input name='ssq_r' readonly/></span><span class='redball'><input name='ssq_r' readonly/></span><span class='redball'><input name='ssq_r' readonly/></span><span class='redball'><input name='ssq_r' readonly/></span><span class='redball'><input name='ssq_r' readonly/></span><span class='redball'><input name='ssq_r' readonly/></span><span class='blueball'><input name='ssq_b' readonly/></span></div><div class='ssq_bb'><a id='ssq_br' class='ssqgrayBtn'>换一注</a><a class='ssqredBtn' id='ssq_bn'>立即投注</a></div>";
ssqbtnRandom = document.getElementById("ssq_br");
ssqbtnBetNow = document.getElementById("ssq_bn");
redBalls = document.getElementsByName("ssq_r");
blueBall = document.getElementsByName("ssq_b")[0];
 
//机选一注
randomOne = function(){
	var red = [], blue, num, i;
	while(red.length < 6){
		num = parseInt(Math.random()*33 + 1);
		if( red.indexOf(num) < 0 )
			red.push(num);
	}
	blue = parseInt(Math.random()*16 + 1);
	//sort
	red = red.sort(function(a,b){return (+a)-(+b)});
	//更新Dom
	for(i=0; i<6; i++)
		redBalls[i].value = ("0"+red[i]).slice(-2);
	blueBall.value = ("0"+blue).slice(-2);
};
ssqbtnRandom.onclick = function(){
	var i=0, t = window.setInterval(function(){
		i++; randomOne();
		if( i >= 5 )window.clearInterval(t);
	}, 70);
	randomOne();
};
randomOne();
//立即投注
ssqbtnBetNow.onclick = function(){
	var red = [], blue, num, i=0;
	for(; i<6; i++){
		num = redBalls[i].value.replace(/\D/g, "");
		if( !num || +num < 1 || +num > 33 || red.indexOf(num)>=0 ){
			redBalls[i].select();
			return;
		}
		red[i] = num;
	}
	blue = blueBall.value;
	if( !blue || +blue < 1 || +blue > 16  ){
		blueBall.select();
		return;
	}
	betNow(red, blue);
};
})(window);
